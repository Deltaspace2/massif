# Handoff: massif front page (v1 redesign)

## Overview
Redesign of the massif front page (`/`) — the live closure & status directory for the Mont Blanc massif. Replaces the current dark GitHub-palette UI (see `frontend/app/layout.tsx` + `globals.css`). Chosen direction: "Alpine editorial" — light, photo-led hero with the answer in a white card, split content/map layout on desktop.

## About the Design Files
The files in this bundle are **design references created in HTML** — they show intended look and behavior, not production code. Recreate them in the massif codebase's existing environment: Next.js App Router with RSC, plain global CSS (no Tailwind), MapLibre GL with the fixed IGN Géoplateforme raster basemap. Keep the existing data model and status strings; this is a presentation-layer rewrite.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final. Recreate pixel-perfectly. Two frames are included in the design file, side by side: desktop 1280px (quiet day, 0 notices) and mobile 390px (active day, 3 notices). The map panes are hatched placeholders — implement with the real MapLibre + IGN raster; marker styling is specified below.

## Core product rules (outrank aesthetics)
1. **A stale "open" must never read as clearance.** Every status row carries its last-confirmed age. Ages > 48h render in caution gold (#8C6D14 text / #B3831D badge) with an UNVERIFIED pill.
2. **The empty state is the default state.** "Nothing unexpectedly shut." must read as a confident verdict, not a failed load: green dot + verdict + counts + sweep time, in the white card overlapping the hero.
3. **Routine vs newsworthy closures are different weights.** Routine ("closed for the day · runs 07:20–16:10") is quiet grey text in the table; newsworthy closures are cards with status-colored headers, source attribution, and quoted decrees.
4. **Unknown is not fine.** Unknown features use the hollow ○ marker, italic "unknown — no information, not «fine»", grey text.
5. Lift dots are **coloured by season, not by the clock** — a lift asleep for the evening is still green.

## Screens / Views

### Desktop / (1280px reference, fluid)
- **Hero**: 560px tall, full-bleed photo (`assets/hero-spires.jpg`, background-position `center 68%`), gradient scrim `linear-gradient(180deg, #fbfcfd08 45%, #22282e5c 100%)`.
  - Top bar: `MASSIF` wordmark (16px, 600, letter-spacing 0.22em, white) left; nav right: `MAP` · `FEED` (12.5px, 500, letter-spacing 0.08em, white, text-shadow `0 1px 8px #22282e59`).
  - Bottom-left (above card): kicker `MONT BLANC MASSIF · FR / IT` (12px, ls 0.24em) + display headline "What's open,\nwhat's shut." (62px, weight 200, line-height 1.05, text-shadow `0 2px 18px #22282e66`).
  - **Verdict card**: white `#fbfcfd`, absolute, left/right 40px, bottom -1px, radius `10px 10px 0 0`, padding 18px 26px, shadow `0 -8px 30px #22282e2b`. Contents in a flex row, gap 22px: 12px green dot `#3d8f63`; "Nothing unexpectedly shut." 19px/500; counts 13px `#6d7681`; right-aligned mono sweep time 11.5px.
- **Content grid**: padding `34px 40px 40px`, `grid-template-columns: 1fr 440px`, gap 44px.
  - **Left column** (gap 26px): UNVERIFIED strip (bg `#f4f0e4`, radius 8px, label 10.5px/700 ls 0.14em `#8c6d14`); two tables — LIFTS & RAILWAYS, ROUTES HUTS & ACCESS. Table header row: 12px/600 ls 0.18em `#6d7681`, hairline `#e3e7ea` under. Rows: grid `14px 1fr auto 64px`, column-gap 14px, padding 10px 0, hairline `#eef1f3`; name 14px/500 + altitude 12.5px `#9aa2ab`; status text 13px `#6d7681` (verbatim operator strings in italics with quotes); age right-aligned IBM Plex Mono 11.5px `#9aa2ab`. Footer disclaimer 12.5px `#9aa2ab`.
  - **Right column: persistent map pane** — white card, border `#e3e7ea`, radius 10px, flex column, min-height 640px. Header row: `MAP · 54 FEATURES` (11px/700 ls 0.14em) + "coloured by season, not by the clock". Map area flex:1 (MapLibre, IGN raster). Legend footer: ● open ▲ restricted ■ closed ○ unknown, 12px.

### Mobile / (390px reference)
- **Hero**: 300px, same photo (`center 66%`), scrim `linear-gradient(180deg, #22282e14 30%, #22282e80 100%)`. Top row: `MASSIF` left; `MAP` `FEED` (11.5px/500 ls 0.08em) + mono timestamp right. Bottom-left: kicker + verdict headline in white 32px/200 ("3 notices in force." on an active day; "Nothing unexpectedly shut." when quiet).
- **Notice cards** (active day, stacked, gap 12px, padding 16px): white cards, border `#e3e7ea`, radius 10px, shadow `0 2px 10px #22282e0f`.
  - Header row: status label 10.5px/700 ls 0.12em (■ CLOSED `#b23c31`, ▲ RESTRICTED `#8c6d14`) + age in mono right.
  - Title 17px/600 + altitude 12px `#9aa2ab`; body 13.5px/1.5 `#4d545c`; official quotes in italic with 2px left border `#e3e7ea`, `#6d7681`; source line mono 10.5px `#9aa2ab` uppercase with ↗.
  - **Unverified notice card**: border `#d8bd7a`, bg `#fdf9ef`, gold pill `UNVERIFIED 3 D` (white on `#b3831d`, radius 999px).
- **Map card**: after notices. Header `MAP · 54 FEATURES` + `FULL SCREEN ↗`; 220px map area; legend footer as desktop. Markers mirror current statuses.
- Collapsed remainder row: "Everything else — 51 features, routine" + `SHOW ↓` (expands the full tables).

## Interactions & Behavior
- Feature names link to `/[type]/[slug]`; source lines (↗) link to the published source in a new tab.
- MAP nav scrolls to / focuses the map pane (desktop) or opens full-screen map (mobile). FEED → `/feed` (planned).
- Mobile `SHOW ↓` expands the routine tables inline (server-rendered, hidden by CSS/details — keep it working without JS if possible; this page is read in huts on bad signal).
- Map markers: 11-12px circles, 2px white ring. Fill by status: open `#3d8f63`, restricted `#b3831d`, closed `#b23c31`; unknown = hollow with 2px dashed `#7c848d` ring. Features with no geometry simply don't appear on the map — never invent coordinates.
- Hover on table rows: subtle bg `#f4f6f8`. Links: default `#22282e` underlined on hover; no browser-default blue.
- No animations required; keep the page fast and static-friendly.

## State Management
- All data is server-rendered from the existing sweep pipeline. Derived per-feature: status (open / restricted / closed / unknown), routine vs notice, last-confirmed age, unverified flag (> 48h or never).
- Page-level: notice count drives the hero headline ("Nothing unexpectedly shut." vs "N notices in force.").
- Sweep timestamp shown in the verdict card; render server time, no client clock needed.

## Design Tokens
- **Background**: page `#fbfcfd`, card white `#ffffff`, ink `#22282e`, body text `#4d545c`, secondary `#6d7681`, tertiary `#9aa2ab`, hairlines `#e3e7ea` / `#eef1f3`.
- **Status**: open `#3d8f63` · restricted `#b3831d` (text-on-light `#8c6d14`, tint bg `#f4f0e4`, unverified card bg `#fdf9ef` border `#d8bd7a`) · closed `#b23c31` · unknown `#7c848d`.
- **Type**: Archivo (200/400/500/600/700) for UI; IBM Plex Mono (400/500/600) for timestamps, ages, source lines, map meta. Google Fonts.
- **Radius**: cards 10px, small chips 6-8px, pills 999px. **Shadows**: card `0 2px 10px #22282e0f`, hero card `0 -8px 30px #22282e2b`.
- Spacing: desktop gutter 40px, column gap 44px, card padding 16-26px, table row padding 10px 0.

## Assets
- `assets/hero-spires.jpg` — user's own photo (rock spires + glacier), included in this bundle. Serve from `frontend/public/backgrounds/`; more of the user's photos live there for future use.
- No icon font: status glyphs are text characters ● ▲ ■ ○.

## Files
- `Massif Front Page - Committed.dc.html` — the committed design (desktop quiet-day frame + mobile active-day frame side by side). Open in a browser.
- `assets/hero-spires.jpg` — hero photo.


---

# UPDATE — Content column: "Ruled Ledger" (supersedes the left-column table spec above)

The desktop left column (inside the `1fr 440px` grid, map pane unchanged) is now the **Ruled Ledger** layout — see `Content Column - Ruled Ledger -9c-.dc.html` in this bundle. Editorial rules and type contrast, no boxed cards except pills/buttons.

## Structure (top to bottom, 44px gaps)
1. **Verdict header** — flex row, `border-bottom: 3px solid #22282e`, padding-bottom 18px:
   - Giant count: 68px/700, line-height 0.85, tabular-nums; `#b23c31` when notices > 0, `#3d8f63` and "0" when quiet.
   - Beside it: "notices in force." 21px/600 (quiet day: "Nothing unexpectedly shut."); below in 13px `#6d7681`: "52 of 54 features routine · sweep 6 min ago · 18:42 CEST".
   - Right-aligned: latest change ("Latest: Grands Montets marked closed · 7 h ago", closed in `#b23c31` 600) + underlined "All changes → feed" link.
2. **IN FORCE NOW** — two-column grid `200px 1fr`, gap 36px. Left: section label 12px/700 ls 0.18em in `#b23c31`, line-broken. Right: notice rows (flex, baseline, gap 14px, padding 12px 0, hairline `#e3e7ea` between): ■ CLOSED label 10.5px/700 `#b23c31` · underlined feature name 16px/600 · altitude+country 12px `#9aa2ab` · status text 13px `#6d7681` · age right-aligned (mono 11px, or gold UNVERIFIED pill: white on `#b3831d`, radius 999px).
3. **LIFTS & RAILWAYS** — same `200px 1fr` grid, section separated by `border-top: 1.5px solid #22282e`, padding-top 16px. Left rail: label in ink + sub-note 12px `#9aa2ab` ("11 tracked / coloured by season, not by the clock"). Right: exception rows first (each with glyph, underlined name, status, age — unverified ages 600 in `#8c6d14`); then the collapsed row: "9 lifts routine, in season · all checked this sweep" + **"Show all 9 ▾" pill button** (12px/600, border `#c6ccd2`, radius 999px, padding 5px 13px, white bg) which expands one quiet line per lift.
4. **ROUTES & ACCESS** — same pattern (in the reference it's folded into the ledger; keep it as its own `200px 1fr` band with 1.5px top rule).
5. **HUTS & REFUGES** — same band; right side is a **2-column grid** (gap 6px 28px) of hut cells: underlined name 13.5px/500 + mono `ALT · CC` 11px `#9aa2ab` (+ amber "N NOTICES" chip where applicable: `#8c6d14` on `#f4f0e4`); second line 11.5px `#9aa2ab` "sleeps N · staffed/unstaffed · water". Left rail note: "24 tracked · highest first / these describe the building, not today". Footnote: Refuges.info CC BY-SA 2.0 attribution + "Country shown per row — the massif spans FR · IT · CH."

## Rules carried over
- Country code after every altitude (`3842 · FR`), mono, never flags.
- Season countdown when < ~30 days: "season ends in **26 days**" (600, ink).
- All feature names underlined: `text-decoration-color: #c6ccd2`, thickness 1px, offset 3px → real links to `/[type]/[slug]`; darken underline on hover.
- Glyphs ● ▲ ■ ○ as before; unknown rows italic grey.
- Mobile: the ledger's 200px label rail collapses — section labels become full-width headers above their content; everything else stacks as in the mobile spec above.
